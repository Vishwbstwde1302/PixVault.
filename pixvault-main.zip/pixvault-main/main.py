from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import uvicorn

# Initialize FastAPI app
app = FastAPI()

# Serve static files (CSS, JS, images)
app.mount("/static", StaticFiles(directory="static"), name="static")

# Set up Jinja2Templates correctly
templates = Jinja2Templates(directory="templates")

# Home Route
@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("homepage.html", {"request": request})

# Other Routes
@app.get("/home", response_class=HTMLResponse)
async def home_page(request: Request):
    return templates.TemplateResponse("home.html", {"request": request})

@app.get("/create-event", response_class=HTMLResponse)
async def create_event(request: Request):
    return templates.TemplateResponse("create_event.html", {"request": request})

@app.get("/events", response_class=HTMLResponse)
async def events(request: Request):
    return templates.TemplateResponse("events.html", {"request": request})

@app.get("/process-images", response_class=HTMLResponse)
async def process_images(request: Request):
    return templates.TemplateResponse("process-images.html", {"request": request})

@app.get("/manage_event_photos", response_class=HTMLResponse)
async def manage_event_photos(request: Request):
    return templates.TemplateResponse("manage_event_photos.html", {"request": request})

@app.get("/manage/{event_id}", response_class=HTMLResponse)
async def manage_event(request: Request, event_id: int):
    return templates.TemplateResponse("manage_event_photos.html", {"request": request, "event_id": event_id})

@app.get("/profile", response_class=HTMLResponse)
async def profile(request: Request):
    return templates.TemplateResponse("profile.html", {"request": request})

# Run the app
if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)
